from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import logging
from contextlib import asynccontextmanager
import asyncio

from app.queue_manager import queue_manager
from app.stealth import harvester

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Ultimate Solver API", lifespan=lifespan)

class WafRequest(BaseModel):
    url: str
    proxy: Optional[str] = None

@app.post("/solve/waf")
async def solve_waf(req: WafRequest):
    try:
        result = await queue_manager.add_task(
            harvester.get_cf_clearance, 
            url=req.url, 
            proxy=req.proxy
        )
        if not result or not result.get("cf_clearance"):
            raise HTTPException(status_code=500, detail="Gagal mendapatkan cf_clearance (Browser crash atau IP diblokir)")
        return {"status": "success", "data": result}
    except asyncio.QueueFull:
        raise HTTPException(status_code=429, detail="Antrean penuh! Server sedang sibuk.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class TurnstileRequest(BaseModel):
    url: str
    sitekey: str
    proxy: Optional[str] = None

@app.post("/solve/turnstile")
async def solve_turnstile(req: TurnstileRequest):
    try:
        result = await queue_manager.add_task(
            harvester.solve_turnstile, 
            url=req.url, 
            sitekey=req.sitekey, 
            proxy=req.proxy
        )
        if not result or not result.get("turnstile_token"):
            raise HTTPException(status_code=500, detail="Gagal mendapatkan token Turnstile (Browser crash atau token timeout)")
        return {"status": "success", "data": result}
    except asyncio.QueueFull:
        raise HTTPException(status_code=429, detail="Antrean penuh! Server sedang sibuk.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
async def get_status():
    return {
        "queue_size": queue_manager.queue.qsize(),
        "max_queue": 6,
        "active_browsers_limit": 3
    }