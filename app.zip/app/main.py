from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict
import logging
import uuid
import asyncio
from contextlib import asynccontextmanager
from app.stealth import solve_turnstile
from app.queue_manager import queue_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TASKS: Dict[str, dict] = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Solverest Replica + Cleaner", lifespan=lifespan)

class SolveRequest(BaseModel):
    sitekey: str
    pageurl: str # Menyesuaikan dengan payload lite-fx9

async def process_task(task_id: str, url: str, sitekey: str):
    TASKS[task_id]["status"] = "processing"
    result = await solve_turnstile(url=url, sitekey=sitekey)
    
    if result and result.get("turnstile_token"):
        TASKS[task_id]["status"] = "done"
        TASKS[task_id]["result"] = result["turnstile_token"]
        TASKS[task_id]["data"] = result
    else:
        TASKS[task_id]["status"] = "failed"
        TASKS[task_id]["error"] = "Gagal mendapatkan token (Timeout / IP Blocked)"

# --- ENDPOINT ASLI SOLVEREST ---
@app.post("/v1/solve/turnstile")
async def submit_turnstile(req: SolveRequest):
    try:
        task_id = str(uuid.uuid4())
        TASKS[task_id] = {"status": "pending", "result": None, "data": None, "error": None}
        
        # Masukkan ke antrean
        await queue_manager.add_task(process_task, task_id, req.pageurl, req.sitekey)
        
        # Langsung balas dengan ID task
        return {"id": task_id}
    except Exception as e:
        raise HTTPException(status_code=429, detail=str(e))

# --- ENDPOINT WAIT (LONG POLLING) ---
@app.get("/v1/tasks/{task_id}/wait")
async def wait_task(task_id: str, timeout: int = 100):
    if task_id not in TASKS:
        raise HTTPException(status_code=404, detail="Task ID tidak ditemukan")
        
    start = asyncio.get_event_loop().time()
    while asyncio.get_event_loop().time() - start < timeout:
        if TASKS[task_id]["status"] == "done":
            return {"status": "done", "result": TASKS[task_id]["result"], "data": TASKS[task_id]["data"]}
        if TASKS[task_id]["status"] == "failed":
            return {"status": "failed", "error": TASKS[task_id]["error"]}
        
        await asyncio.sleep(1) # Cek internal tiap 1 detik
        
    return {"status": "timeout", "error": "Waktu tunggu habis"}

@app.get("/status")
async def get_status():
    return {
        "queue_size": queue_manager.queue.qsize(),
        "active_browsers": queue_manager.browser_semaphore._value
    }
