from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import logging
from contextlib import asynccontextmanager
from app.stealth import solve_waf, solve_turnstile
from app.queue_manager import queue_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Solverest Replica + CF WAF", lifespan=lifespan)

class WafRequest(BaseModel):
    url: str
    proxy: Optional[str] = None

class TurnstileRequest(BaseModel):
    url: str
    sitekey: str
    proxy: Optional[str] = None

@app.post("/solve/waf")
async def api_solve_waf(req: WafRequest):
    try:
        result = await queue_manager.add_task(solve_waf, url=req.url, proxy=req.proxy)
        if not result or not result.get("cf_clearance"):
            raise HTTPException(status_code=500, detail="Gagal mendapatkan cf_clearance")
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/solve/turnstile")
async def api_solve_turnstile(req: TurnstileRequest):
    try:
        result = await queue_manager.add_task(
            solve_turnstile, url=req.url, sitekey=req.sitekey, proxy=req.proxy
        )
        if not result or not result.get("turnstile_token"):
            raise HTTPException(status_code=500, detail="Gagal mendapatkan token Turnstile")
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status")
async def get_status():
    return {
        "queue_size": queue_manager.queue.qsize(),
        "active_browsers": queue_manager.browser_semaphore._value
    }
