from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict
import logging
import uuid
import asyncio
from contextlib import asynccontextmanager
from app.stealth import process_turnstile_and_cf
from app.queue_manager import queue_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TASKS: Dict[str, dict] = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Ultimate Patchright Solver", lifespan=lifespan)

class SolveRequest(BaseModel):
    sitekey: str
    pageurl: str

async def process_task(task_id: str, url: str, sitekey: str):
    TASKS[task_id]["status"] = "processing"
    try:
        result = await process_turnstile_and_cf(url=url, sitekey=sitekey)
        TASKS[task_id]["status"] = "done"
        TASKS[task_id]["result"] = result["turnstile_token"]
        TASKS[task_id]["data"] = result
    except Exception as e:
        logger.error(f"Task {task_id} Error: {e}")
        TASKS[task_id]["status"] = "failed"
        TASKS[task_id]["error"] = str(e)

@app.post("/v1/solve/turnstile")
async def submit_turnstile(req: SolveRequest):
    try:
        task_id = str(uuid.uuid4())
        TASKS[task_id] = {"status": "pending", "result": None, "data": None, "error": None}
        await queue_manager.add_task(process_task, task_id, req.pageurl, req.sitekey)
        return {"id": task_id}
    except Exception as e:
        raise HTTPException(status_code=429, detail=str(e))

@app.get("/v1/tasks/{task_id}/wait")
async def wait_task(task_id: str, timeout: int = 100):
    if task_id not in TASKS:
        raise HTTPException(status_code=404, detail="Task ID tidak ditemukan")
        
    start = asyncio.get_event_loop().time()
    while asyncio.get_event_loop().time() - start < timeout:
        status = TASKS[task_id]["status"]
        if status == "done":
            return {"status": "done", "result": TASKS[task_id]["result"], "data": TASKS[task_id]["data"]}
        if status == "failed":
            return {"status": "failed", "error": TASKS[task_id]["error"]}
        await asyncio.sleep(1)
        
    return {"status": "timeout", "error": "Waktu tunggu habis"}

@app.get("/status")
async def get_status():
    return {"queue_size": queue_manager.queue.qsize(), "active_browsers": queue_manager.browser_semaphore._value}
