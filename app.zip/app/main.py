from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import logging
from contextlib import asynccontextmanager

from app.queue_manager import queue_manager
from app.stealth import harvester

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Jalankan background worker saat startup
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Ultimate Solver API", lifespan=lifespan)

# --- ENDPOINT 1: KHUSUS WAF ---
class WafRequest(BaseModel):
    url: str
    proxy: Optional[str] = None

@app.post("/solve/waf")
async def solve_waf(req: WafRequest):
    try:
        result = await queue_manager.add_task(
            harvester.get_cf_clearance, 
            url=req.url, 
            proxy=req.proxy
        )
        if not result or not result["cf_clearance"]:
            raise HTTPException(status_code=500, detail="Gagal mendapatkan cf_clearance")
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=429, detail=str(e))

# --- ENDPOINT 2: KHUSUS TURNSTILE ---
class TurnstileRequest(BaseModel):
    url: str
    sitekey: str
    proxy: Optional[str] = None

@app.post("/solve/turnstile")
async def solve_turnstile(req: TurnstileRequest):
    try:
        result = await queue_manager.add_task(
            harvester.solve_turnstile, 
            url=req.url, 
            sitekey=req.sitekey, 
            proxy=req.proxy
        )
        if not result or not result["turnstile_token"]:
            raise HTTPException(status_code=500, detail="Gagal mendapatkan token Turnstile")
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=429, detail=str(e))

@app.get("/status")
async def get_status():
    return {
        "queue_size": queue_manager.queue.qsize(),
        "max_queue": 6,
        "active_browsers_limit": 3
    }
