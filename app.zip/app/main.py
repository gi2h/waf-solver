from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict
import logging
import uuid
from contextlib import asynccontextmanager
from app.stealth import solve_turnstile
from app.queue_manager import queue_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TASKS: Dict[str, dict] = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    await queue_manager.start_worker()
    yield

app = FastAPI(title="Solver API Polling System", lifespan=lifespan)

class TurnstileRequest(BaseModel):
    url: str
    sitekey: str

async def process_task(task_id: str, url: str, sitekey: str):
    TASKS[task_id]["status"] = "processing"
    result = await solve_turnstile(url=url, sitekey=sitekey)
    
    if result and result.get("turnstile_token"):
        TASKS[task_id]["status"] = "success"
        TASKS[task_id]["data"] = result
    else:
        TASKS[task_id]["status"] = "failed"
        TASKS[task_id]["error"] = "Gagal mendapatkan token (Timeout / IP Blocked)"

@app.post("/solve/turnstile")
async def submit_turnstile(req: TurnstileRequest):
    try:
        task_id = str(uuid.uuid4())
        TASKS[task_id] = {"status": "pending", "data": None, "error": None}
        
        await queue_manager.add_task(process_task, task_id, req.url, req.sitekey)
        
        return {"status": "submitted", "task_id": task_id}
    except Exception as e:
        raise HTTPException(status_code=429, detail=str(e))

@app.get("/task/{task_id}")
async def get_task_status(task_id: str):
    if task_id not in TASKS:
        raise HTTPException(status_code=404, detail="Task ID tidak ditemukan")
    return TASKS[task_id]

@app.get("/status")
async def get_status():
    return {
        "queue_size": queue_manager.queue.qsize(),
        "active_browsers": queue_manager.browser_semaphore._value
    }
