import asyncio
import logging

logger = logging.getLogger(__name__)

MAX_QUEUE_SIZE = 6
MAX_ACTIVE_BROWSERS = 3

class QueueManager:
    def __init__(self):
        # Antrean maksimal 6 tugas
        self.queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        # Batasi 3 browser aktif bersamaan
        self.browser_semaphore = asyncio.Semaphore(MAX_ACTIVE_BROWSERS)
        self.worker_task = None

    async def start_worker(self):
        if self.worker_task is None:
            self.worker_task = asyncio.create_task(self._process_queue())
            logger.info("Queue Worker berjalan.")

    async def add_task(self, task_func, *args, **kwargs):
        if self.queue.full():
            raise Exception("Antrean penuh! Server sedang sibuk (Maksimal 6 tugas).")
        
        future = asyncio.Future()
        await self.queue.put((future, task_func, args, kwargs))
        return await future

    async def _process_queue(self):
        while True:
            future, task_func, args, kwargs = await self.queue.get()
            try:
                # Tunggu sampai ada slot browser yang kosong (Maks 3)
                async with self.browser_semaphore:
                    result = await task_func(*args, **kwargs)
                    future.set_result(result)
            except Exception as e:
                future.set_exception(e)
            finally:
                self.queue.task_done()

queue_manager = QueueManager()
