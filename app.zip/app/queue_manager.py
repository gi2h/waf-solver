import asyncio
import logging

logger = logging.getLogger(__name__)

MAX_QUEUE_SIZE = 6
MAX_ACTIVE_BROWSERS = 2

class QueueManager:
    def __init__(self):
        self.queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.browser_semaphore = asyncio.Semaphore(MAX_ACTIVE_BROWSERS)
        self.worker_task = None

    async def start_worker(self):
        if self.worker_task is None:
            self.worker_task = asyncio.create_task(self._process_queue())
            logger.info(f"Queue Worker berjalan. (Max Antrean: {MAX_QUEUE_SIZE}, Max Browser: {MAX_ACTIVE_BROWSERS})")

    async def add_task(self, task_func, *args, **kwargs):
        if self.queue.full():
            raise Exception("Antrean penuh! (Maksimal 6 tugas).")
        await self.queue.put((task_func, args, kwargs))

    async def _process_queue(self):
        while True:
            task_func, args, kwargs = await self.queue.get()
            try:
                async with self.browser_semaphore:
                    await task_func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Task Error: {e}")
            finally:
                self.queue.task_done()
                logger.info(f"Task selesai. Sisa antrean: {self.queue.size()}")

queue_manager = QueueManager()
