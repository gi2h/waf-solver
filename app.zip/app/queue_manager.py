import asyncio
import logging

logger = logging.getLogger(__name__)

MAX_QUEUE_SIZE = 6
MAX_ACTIVE_BROWSERS = 2  # Maksimal 2 browser aktif

class QueueManager:
    def __init__(self):
        self.queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.browser_semaphore = asyncio.Semaphore(MAX_ACTIVE_BROWSERS)
        self.worker_task = None

    async def start_worker(self):
        if self.worker_task is None:
            self.worker_task = asyncio.create_task(self._process_queue())
            logger.info(f"Queue Worker berjalan. (Antrean Maks: {MAX_QUEUE_SIZE}, Browser Aktif: {MAX_ACTIVE_BROWSERS})")

    async def add_task(self, task_func, *args, **kwargs):
        if self.queue.full():
            raise Exception("Antrean penuh! Server sedang sibuk (Maksimal 6 tugas).")
        future = asyncio.Future()
        await self.queue.put((future, task_func, args, kwargs))
        return await future

    async def _process_queue(self):
        while True:
            future, task_func, args, kwargs = await self.queue.get()
            try:
                async with self.browser_semaphore:
                    result = await task_func(*args, **kwargs)
                    future.set_result(result)
            except Exception as e:
                logger.error(f"Task Error: {e}")
                future.set_exception(e)
            finally:
                self.queue.task_done()
                logger.info(f"Task selesai. Sisa antrean: {self.queue.qsize()}")

queue_manager = QueueManager()
