import nodriver as uc
import asyncio
import time
import logging

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        args = ["--headless=new", "--no-sandbox", "--disable-dev-shm-usage"]
        if proxy:
            args.append(f"--proxy-server={proxy}")
        return await uc.start(browser_args=args)

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        """Metode 1: Bypass WAF dan ambil cf_clearance"""
        logger.info(f"[WAF] Membuka: {url}")
        browser = await self._init_browser(proxy)
        cf_clearance = None
        
        try:
            page = await browser.get(url)
            start = time.time()
            
            while time.time() - start < timeout:
                title = await page.evaluate("document.title")
                if "Just a moment" not in title:
                    logger.info("[WAF] Cloudflare WAF berhasil dilewati.")
                    break
                await asyncio.sleep(2)
            
            cookies = await browser.cookies.get_all()
            for c in cookies:
                if c.name == "cf_clearance":
                    cf_clearance = c.value
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            return {"cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[WAF] Error: {e}")
            return None
        finally:
            browser.stop()

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 60):
        """Metode 2: Ambil token Turnstile (dan cf_clearance jika ada)"""
        logger.info(f"[TURNSTILE] Membuka: {url}")
        browser = await self._init_browser(proxy)
        token = None
        cf_clearance = None
        
        try:
            page = await browser.get(url)
            
            # Tunggu WAF lewat jika ada
            start = time.time()
            while time.time() - start < timeout:
                title = await page.evaluate("document.title")
                if "Just a moment" not in title:
                    break
                await asyncio.sleep(2)
                
            # Tunggu token Turnstile muncul di halaman
            logger.info("[TURNSTILE] Menunggu token di-generate...")
            while time.time() - start < timeout:
                token = await page.evaluate('''
                    document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                    document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                    null
                ''')
                if token: break
                await asyncio.sleep(2)
                
            cookies = await browser.cookies.get_all()
            for c in cookies:
                if c.name == "cf_clearance":
                    cf_clearance = c.value
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[TURNSTILE] Error: {e}")
            return None
        finally:
            browser.stop()

harvester = CFHarvester()
