import asyncio
import time
import logging
from playwright.async_api import async_playwright

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu",
            "--blink-settings=imagesEnabled=false"
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
            
        logger.info("[BROWSER] Memulai Chromium via Playwright...")
        try:
            playwright = await async_playwright().start()
            browser = await playwright.chromium.launch(headless=True, args=args)
            logger.info("[BROWSER] Chromium berhasil menyala!")
            return playwright, browser
        except Exception as e:
            logger.error(f"[BROWSER ERROR] Gagal start: {e}")
            return None, None

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 90):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        playwright, browser = await self._init_browser(proxy)
        
        if not browser:
            return None

        token = None
        cf_clearance = None

        try:
            page = await browser.new_page()
            await page.goto(url, timeout=60000, wait_until="domcontentloaded")
            
            start = time.time()
            waf_passed = False

            # ==========================================
            # TAHAP 1: CEK APAKAH MASIH DI HALAMAN WAF
            # ==========================================
            logger.info("[WAF] Mulai mengecek status halaman...")
            while time.time() - start < timeout:
                try:
                    title = await page.title()
                    
                    if "Just a moment" in title or "Attention Required" in title:
                        logger.warning(f"[WAF] Masih tertahan di Cloudflare. Title: '{title}'")
                    else:
                        logger.info(f"[WAF] Berhasil melewati WAF! Title: '{title}'")
                        waf_passed = True
                        break
                except Exception as e:
                    pass
                
                await asyncio.sleep(3)

            if not waf_passed:
                logger.error("[WAF] Timeout! Gagal melewati Cloudflare.")
                # Lanjut ke turnstile saja untuk berjaga-jaga

            # ==========================================
            # TAHAP 2: MENUNGGU TOKEN TURNSTILE
            # ==========================================
            logger.info("[TURNSTILE] Menunggu token di-generate (maksimal 90 detik)...")
            
            while time.time() - start < timeout:
                try:
                    # Cek apakah iframe Turnstile ada
                    iframe_count = await page.locator('iframe').count()
                    
                    # Coba baca token
                    token = await page.evaluate('''
                        document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                        document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                        null
                    ''')
                    
                    if token:
                        logger.info(f"[TURNSTILE] SUKSES! Token ditemukan (Panjang: {len(token)})")
                        break
                    else:
                        # Cetak log setiap 5 detik sekali agar tidak spam
                        if int(time.time() - start) % 5 == 0:
                            logger.info(f"[TURNSTILE] Masih menunggu token... (Iframe ditemukan: {iframe_count})")
                            
                except Exception:
                    pass
                
                await asyncio.sleep(2)

            if not token:
                logger.warning("[TURNSTILE] Gagal mendapatkan token (Timeout).")

            # ==========================================
            # TAHAP 3: AMBIL COOKIES
            # ==========================================
            cookies = await page.context.cookies()
            for c in cookies:
                if c["name"] == "cf_clearance":
                    cf_clearance = c["value"]
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
            
        except Exception as e:
            logger.error(f"[ERROR FATAL] {e}")
            return None
        finally:
            if browser:
                await browser.close()
            if playwright:
                await playwright.stop()

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        # (Sama seperti sebelumnya, tidak perlu diubah untuk saat ini)
        pass

harvester = CFHarvester()