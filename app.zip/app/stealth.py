import asyncio
import time
import logging
from playwright.async_api import async_playwright

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        # Hanya flag standar untuk stabilitas di Docker
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox"
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
            
        logger.info("[BROWSER] Memulai Chromium (Mode Full UI / Headful)...")
        try:
            playwright = await async_playwright().start()
            
            # HEADLESS FALSE: Menjalankan browser seperti aslinya
            browser = await playwright.chromium.launch(headless=False, args=args)
            
            logger.info("[BROWSER] Chromium berhasil menyala dengan Full Feature!")
            return playwright, browser
        except Exception as e:
            logger.error(f"[BROWSER ERROR] Gagal start: {e}")
            return None, None

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 90):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        playwright, browser = await self._init_browser(proxy)
        
        if not browser:
            return None

        token = None
        cf_clearance = None

        try:
            # Buat konteks baru dengan User-Agent asli
            context = await browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            )
            
            page = await context.new_page()
            
            # TRIK STEALTH: Sembunyikan jejak otomasi Playwright
            await page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                window.chrome = { runtime: {} };
                Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
                Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
            """)
            
            await page.goto(url, timeout=60000, wait_until="domcontentloaded")
            
            start = time.time()
            waf_passed = False

            # ==========================================
            # TAHAP 1: CEK APAKAH MASIH DI HALAMAN WAF
            # ==========================================
            logger.info("[WAF] Mulai mengecek status halaman...")
            while time.time() - start < timeout:
                try:
                    title = await page.title()
                    
                    if "Just a moment" in title or "Attention Required" in title:
                        logger.warning(f"[WAF] Masih tertahan di Cloudflare. Title: '{title}'")
                    else:
                        logger.info(f"[WAF] Berhasil melewati WAF! Title: '{title}'")
                        waf_passed = True
                        break
                except Exception:
                    pass
                
                await asyncio.sleep(3)

            if not waf_passed:
                logger.error("[WAF] Timeout! Gagal melewati Cloudflare.")

            # ==========================================
            # TAHAP 2: MENUNGGU TOKEN TURNSTILE
            # ==========================================
            logger.info("[TURNSTILE] Menunggu token di-generate (maksimal 90 detik)...")
            
            while time.time() - start < timeout:
                try:
                    token = await page.evaluate('''
                        document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                        document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                        null
                    ''')
                    
                    if token:
                        logger.info(f"[TURNSTILE] SUKSES! Token ditemukan (Panjang: {len(token)})")
                        break
                    else:
                        if int(time.time() - start) % 5 == 0:
                            logger.info(f"[TURNSTILE] Masih menunggu token...")
                            
                except Exception:
                    pass
                
                await asyncio.sleep(2)

            if not token:
                logger.warning("[TURNSTILE] Gagal mendapatkan token (Timeout).")

            # ==========================================
            # TAHAP 3: AMBIL COOKIES
            # ==========================================
            cookies = await page.context.cookies()
            for c in cookies:
                if c["name"] == "cf_clearance":
                    cf_clearance = c["value"]
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
            
        except Exception as e:
            logger.error(f"[ERROR FATAL] {e}")
            return None
        finally:
            if browser:
                await browser.close()
            if playwright:
                await playwright.stop()

harvester = CFHarvester()