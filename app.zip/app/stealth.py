import asyncio
import time
import logging
from playwright.async_api import async_playwright

logger = logging.getLogger(__name__)

async def _get_page_context(url: str):
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(
        headless=False, # Mode Headful
        args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-setuid-sandbox", "--disable-gpu", "--window-size=1920,1080"]
    )
    context = await browser.new_context(
        viewport={"width": 1920, "height": 1080},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    )
    page = await context.new_page()
    await page.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        window.chrome = { runtime: {} };
    """)
    await page.goto(url, timeout=60000, wait_until="domcontentloaded")
    return playwright, browser, context, page

# --- TAMBAHAN: FUNGSI CLEANER ---
async def _cleaner(context, browser, playwright):
    try:
        if context: await context.close()
        if browser: await browser.close()
        if playwright: await playwright.stop()
        logger.info("[CLEANER] Browser & Context berhasil dibersihkan.")
    except Exception as e:
        logger.warning(f"[CLEANER ERROR] {e}")

async def solve_turnstile(url: str, sitekey: str, timeout: int = 90):
    logger.info(f"[TURNSTILE] Memproses: {url}")
    playwright, browser, context, page = await _get_page_context(url)
    token = None
    cf_clearance = None
    ua = None
    start = time.time()
    
    try:
        # Logika asli: Tunggu WAF lewat jika ada
        while time.time() - start < timeout:
            title = await page.title()
            if "Just a moment" not in title:
                break
            await asyncio.sleep(2)
        
        # Logika asli: Tunggu token Turnstile
        logger.info("[TURNSTILE] Menunggu token...")
        while time.time() - start < timeout:
            token = await page.evaluate("""
                document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                document.querySelector('input[name="g-recaptcha-response"]')?.value || null
            """)
            if token: break
            await asyncio.sleep(2)
            
        cookies = await context.cookies()
        for c in cookies:
            if c["name"] == "cf_clearance":
                cf_clearance = c["value"]
                break
        ua = await page.evaluate("navigator.userAgent")
    except Exception as e:
        logger.error(f"[TURNSTILE] Error: {e}")
    finally:
        # --- TAMBAHAN: SELALU BERSIHKAN ---
        await _cleaner(context, browser, playwright)
        
    return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
