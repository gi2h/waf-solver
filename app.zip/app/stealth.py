import asyncio
import time
import logging
from patchright.async_api import async_playwright

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu",
            "--blink-settings=imagesEnabled=false",
            "--disable-features=IsolateOrigins,site-per-process"
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
            
        logger.info("[BROWSER] Memulai Chrome via Patchright...")
        try:
            p = await async_playwright().start()
            browser = await p.chromium.launch(headless=True, args=args)
            logger.info("[BROWSER] Chrome berhasil menyala!")
            return p, browser
        except Exception as e:
            logger.error(f"[BROWSER ERROR] Gagal start: {e}")
            return None, None

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 90):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        p, browser = await self._init_browser(proxy)
        if not browser:
            return None

        token = None
        cf_clearance = None

        try:
            page = await browser.new_page()
            await page.goto(url, timeout=30000)
            
            start = time.time()
            # Tunggu WAF lewat dan token muncul
            while time.time() - start < timeout:
                # Ambil token dari input hidden
                token = await page.evaluate('''
                    document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                    document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                    null
                ''')
                if token:
                    logger.info("[TURNSTILE] Token ditemukan!")
                    break
                await asyncio.sleep(2)
                
            # Ambil cf_clearance
            cookies = await page.context.cookies()
            for c in cookies:
                if c["name"] == "cf_clearance":
                    cf_clearance = c["value"]
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[TURNSTILE] Error: {e}")
            return None
        finally:
            if browser:
                await browser.close()
            if p:
                await p.stop()

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        # (Implementasi serupa dengan di atas, hanya mencari cf_clearance)
        pass

harvester = CFHarvester()