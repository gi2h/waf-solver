import nodriver as uc
import asyncio
import time
import logging

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        # HAPUS --single-process dan --no-zygote. 
        # Tambahkan --blink-settings untuk mematikan gambar (hemat RAM & bandwidth)
        args = [
            "--headless=new", 
            "--no-sandbox", 
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu",
            "--disable-software-rasterizer",
            "--disable-extensions",
            "--blink-settings=imagesEnabled=false", 
            "--disable-features=IsolateOrigins,site-per-process"
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
        
        logger.info(f"[BROWSER] Memulai Chrome...")
        try:
            browser = await asyncio.wait_for(uc.start(browser_args=args), timeout=45)
            logger.info("[BROWSER] Chrome berhasil menyala!")
            return browser
        except asyncio.TimeoutError:
            logger.error("[BROWSER ERROR] Timeout! Chrome hang. Kemungkinan RAM habis.")
            return None
        except Exception as e:
            logger.error(f"[BROWSER ERROR] Gagal start: {e}")
            return None

    def _safe_stop(self, browser):
        if browser:
            try:
                browser.stop()
            except Exception:
                pass

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 90):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        browser = await self._init_browser(proxy)
        token = None
        cf_clearance = None
        
        if browser is None:
            return None

        try:
            page = await asyncio.wait_for(browser.get(url), timeout=30)
            start = time.time()
            
            # 1. Tunggu halaman selesai loading (WAF bypass)
            while time.time() - start < timeout:
                try:
                    title = await page.evaluate("document.title")
                    if title and "Just a moment" not in title:
                        break
                except:
                    pass
                await asyncio.sleep(2)
                
            logger.info("[TURNSTILE] Menunggu token di-generate...")
            
            # 2. Loop untuk mencari token Turnstile
            while time.time() - start < timeout:
                try:
                    # Coba ambil token dari input hidden
                    token = await page.evaluate('''
                        document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                        document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                        null
                    ''')
                    if token:
                        logger.info("[TURNSTILE] Token ditemukan di DOM!")
                        break
                except Exception as e:
                    # Abaikan error evaluate jika page sedang reload
                    pass
                await asyncio.sleep(2)
                
            # 3. Ambil cookies cf_clearance
            try:
                cookies = await browser.cookies.get_all()
                for c in cookies:
                    if c.name == "cf_clearance":
                        cf_clearance = c.value
                        break
                        
                ua = await page.evaluate("navigator.userAgent")
            except:
                ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                
            if not token:
                logger.warning("[TURNSTILE] Gagal mendapatkan token (Timeout).")
                
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[TURNSTILE] Error: {e}")
            return None
        finally:
            self._safe_stop(browser)

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        # (Kode ini sama seperti sebelumnya, tidak perlu diubah)
        logger.info(f"[WAF] Membuka: {url}")
        browser = await self._init_browser(proxy)
        if browser is None: return None
        cf_clearance = None
        try:
            page = await asyncio.wait_for(browser.get(url), timeout=30)
            start = time.time()
            while time.time() - start < timeout:
                try:
                    title = await page.evaluate("document.title")
                    if title and "Just a moment" not in title:
                        break
                except: pass
                await asyncio.sleep(2)
            
            cookies = await browser.cookies.get_all()
            for c in cookies:
                if c.name == "cf_clearance":
                    cf_clearance = c.value
                    break
            ua = await page.evaluate("navigator.userAgent")
            return {"cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[WAF] Error: {e}")
            return None
        finally:
            self._safe_stop(browser)

harvester = CFHarvester()