import asyncio
import time
import logging
from playwright.async_api import async_playwright

logger = logging.getLogger(__name__)

async def _get_page_context(url: str, proxy: str = None):
    playwright = await async_playwright().start()
    
    browser = await playwright.chromium.launch(
        headless=False,  # Mode Headful (Butuh xvfb di Docker)
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu",
            "--window-size=1920,1080",
            "--disable-blink-features=AutomationControlled"
        ]
    )
    
    context = await browser.new_context(
        viewport={"width": 1920, "height": 1080},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        proxy={"server": proxy} if proxy else None
    )
    
    page = await context.new_page()
    
    # Stealth Script (Menyembunyikan otomasi)
    await page.add_init_script('''
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        window.chrome = { runtime: {} };
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
    ''')
    
    await page.goto(url, timeout=60000, wait_until="domcontentloaded")
    return playwright, browser, context, page

async def _cleaner(context, browser, playwright):
    """CLEANER: Menutup semua resource untuk mencegah kebocoran RAM"""
    try:
        if context:
            await context.clear_cookies()
            await context.close()
        if browser:
            await browser.close()
        if playwright:
            await playwright.stop()
        logger.info("[CLEANER] Semua resource berhasil dibersihkan.")
    except Exception as e:
        logger.warning(f"[CLEANER ERROR] Gagal membersihkan: {e}")

# ==========================================
# ENDPOINT 1: CF WAF (Ambil cf_clearance)
# ==========================================
async def solve_waf(url: str, proxy: str = None, timeout: int = 60):
    logger.info(f"[WAF] Memproses: {url}")
    playwright, browser, context, page = await _get_page_context(url, proxy)
    cf_clearance = None
    ua = None
    start = time.time()
    
    try:
        while time.time() - start < timeout:
            title = await page.title()
            if "Just a moment" not in title and "Attention Required" not in title:
                logger.info(f"[WAF] Berhasil. Title: '{title}'")
                break
            await asyncio.sleep(2)
            
        cookies = await context.cookies()
        for c in cookies:
            if c["name"] == "cf_clearance":
                cf_clearance = c["value"]
                break
        ua = await page.evaluate("navigator.userAgent")
    except Exception as e:
        logger.error(f"[WAF] Error: {e}")
    finally:
        await _cleaner(context, browser, playwright)
        
    return {"cf_clearance": cf_clearance, "user_agent": ua}

# ==========================================
# ENDPOINT 2: TURNSTILE (Ambil token & cf_clearance)
# ==========================================
async def solve_turnstile(url: str, sitekey: str, proxy: str = None, timeout: int = 90):
    logger.info(f"[TURNSTILE] Memproses: {url}")
    playwright, browser, context, page = await _get_page_context(url, proxy)
    token = None
    cf_clearance = None
    ua = None
    start = time.time()
    
    try:
        # 1. Tunggu WAF lewat
        while time.time() - start < timeout:
            title = await page.title()
            if "Just a moment" not in title:
                break
            await asyncio.sleep(2)
        
        # 2. Tunggu Turnstile
        logger.info("[TURNSTILE] Menunggu token di-generate...")
        while time.time() - start < timeout:
            token = await page.evaluate('''
                document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                null
            ''')
            if token:
                logger.info("[TURNSTILE] Token ditemukan!")
                break
            await asyncio.sleep(2)
            
        # 3. Ambil cf_clearance
        cookies = await context.cookies()
        for c in cookies:
            if c["name"] == "cf_clearance":
                cf_clearance = c["value"]
                break
        ua = await page.evaluate("navigator.userAgent")
    except Exception as e:
        logger.error(f"[TURNSTILE] Error: {e}")
    finally:
        await _cleaner(context, browser, playwright)
        
    return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
