import nodriver as uc
import asyncio
import time
import logging

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        args = [
            "--headless=new", 
            "--no-sandbox", 
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu"
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
        
        try:
            # Beri timeout 30 detik agar tidak menggantung jika Chrome gagal start
            return await asyncio.wait_for(uc.start(browser_args=args), timeout=30)
        except Exception as e:
            logger.error(f"[BROWSER INIT ERROR] Chrome gagal dijalankan: {e}")
            return None

    def _safe_stop(self, browser):
        """Fungsi pengaman untuk menutup browser tanpa memicu NoneType error"""
        if browser:
            try:
                browser.stop()
            except Exception as e:
                logger.warning(f"Gagal menutup browser dengan bersih: {e}")

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        logger.info(f"[WAF] Membuka: {url}")
        browser = await self._init_browser(proxy)
        
        if browser is None:
            return None

        cf_clearance = None
        try:
            page = await browser.get(url)
            start = time.time()
            
            while time.time() - start < timeout:
                title = await page.evaluate("document.title")
                if title and "Just a moment" not in title:
                    logger.info("[WAF] Cloudflare WAF berhasil dilewati.")
                    break
                await asyncio.sleep(2)
            
            cookies = await browser.cookies.get_all()
            for c in cookies:
                if c.name == "cf_clearance":
                    cf_clearance = c.value
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            return {"cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[WAF] Error saat memproses halaman: {e}")
            return None
        finally:
            self._safe_stop(browser)

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 60):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        browser = await self._init_browser(proxy)
        token = None
        cf_clearance = None
        
        if browser is None:
            return None

        try:
            page = await browser.get(url)
            start = time.time()
            
            # Tunggu WAF lewat
            while time.time() - start < timeout:
                title = await page.evaluate("document.title")
                if title and "Just a moment" not in title:
                    break
                await asyncio.sleep(2)
                
            # Tunggu token Turnstile
            logger.info("[TURNSTILE] Menunggu token di-generate...")
            while time.time() - start < timeout:
                token = await page.evaluate('''
                    document.querySelector('input[name="cf-turnstile-response"]')?.value || 
                    document.querySelector('input[name="g-recaptcha-response"]')?.value || 
                    null
                ''')
                if token: break
                await asyncio.sleep(2)
                
            cookies = await browser.cookies.get_all()
            for c in cookies:
                if c.name == "cf_clearance":
                    cf_clearance = c.value
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[TURNSTILE] Error saat memproses halaman: {e}")
            return None
        finally:
            self._safe_stop(browser)

harvester = CFHarvester()