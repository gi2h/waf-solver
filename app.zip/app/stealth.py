import asyncio
import time
import logging
from playwright.async_api import async_playwright

logger = logging.getLogger(__name__)

class CFHarvester:
    async def _init_browser(self, proxy: str = None):
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-setuid-sandbox",
            "--disable-gpu",
            "--blink-settings=imagesEnabled=false" # Hemat RAM
        ]
        if proxy:
            args.append(f"--proxy-server={proxy}")
            
        logger.info("[BROWSER] Memulai Chromium via Playwright...")
        try:
            playwright = await async_playwright().start()
            browser = await playwright.chromium.launch(headless=True, args=args)
            logger.info("[BROWSER] Chromium berhasil menyala!")
            return playwright, browser
        except Exception as e:
            logger.error(f"[BROWSER ERROR] Gagal start: {e}")
            return None, None

    async def solve_turnstile(self, url: str, sitekey: str, proxy: str = None, timeout: int = 90):
        logger.info(f"[TURNSTILE] Membuka: {url}")
        playwright, browser = await self._init_browser(proxy)
        
        if not browser:
            return None

        token = None
        cf_clearance = None

        try:
            page = await browser.new_page()
            await page.goto(url, timeout=60000, wait_until="domcontentloaded")
            
            logger.info("[TURNSTILE] Menunggu token di-generate...")
            
            # Playwright punya fitur wait_for_function yang sangat stabil
            # Ini akan menunggu sampai input hidden terisi oleh Turnstile Cloudflare
            await page.wait_for_function('''
                () => {
                    const el = document.querySelector('input[name="cf-turnstile-response"]') 
                            || document.querySelector('input[name="g-recaptcha-response"]');
                    return el && el.value && el.value.length > 20;
                }
            ''', timeout=timeout * 1000)
            
            token = await page.evaluate('''
                (document.querySelector('input[name="cf-turnstile-response"]')?.value) || 
                (document.querySelector('input[name="g-recaptcha-response"]')?.value)
            ''')
            
            if token:
                logger.info("[TURNSTILE] Token berhasil didapatkan!")
                
            # Ambil cookies (cf_clearance)
            cookies = await page.context.cookies()
            for c in cookies:
                if c["name"] == "cf_clearance":
                    cf_clearance = c["value"]
                    break
                    
            ua = await page.evaluate("navigator.userAgent")
            
            return {"turnstile_token": token, "cf_clearance": cf_clearance, "user_agent": ua}
            
        except Exception as e:
            logger.error(f"[TURNSTILE] Error/Timeout: {e}")
            return None
        finally:
            if browser:
                await browser.close()
            if playwright:
                await playwright.stop()

    async def get_cf_clearance(self, url: str, proxy: str = None, timeout: int = 60):
        # Implementasi WAF only
        logger.info(f"[WAF] Membuka: {url}")
        playwright, browser = await self._init_browser(proxy)
        if not browser: return None
        cf_clearance = None
        try:
            page = await browser.new_page()
            await page.goto(url, timeout=60000, wait_until="domcontentloaded")
            await asyncio.sleep(5) # Tunggu WAF bypass
            cookies = await page.context.cookies()
            for c in cookies:
                if c["name"] == "cf_clearance":
                    cf_clearance = c["value"]
                    break
            ua = await page.evaluate("navigator.userAgent")
            return {"cf_clearance": cf_clearance, "user_agent": ua}
        except Exception as e:
            logger.error(f"[WAF] Error: {e}")
            return None
        finally:
            if browser: await browser.close()
            if playwright: await playwright.stop()

harvester = CFHarvester()